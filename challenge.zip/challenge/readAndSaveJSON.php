<?php
// Read JSON data from the file
$jsonData = file_get_contents('events.json');

// Convert JSON to associative array
$bookings = json_decode($jsonData, true);

// Connect to the database
include 'connect.php';

// Prepare the SQL statement
$sql = "INSERT INTO bookings (participation_id, employee_name, employee_mail, event_id, event_name, participation_fee, event_date, version) VALUES (:participation_id, :employee_name, :employee_mail, :event_id, :event_name, :participation_fee, :event_date, :version)";
$stmt = $db->prepare($sql);

// Insert each booking into the database
foreach ($bookings as $booking) {
    $stmt->execute([
        'participation_id' => $booking['participation_id'],
        'employee_name' => $booking['employee_name'],
        'employee_mail' => $booking['employee_mail'],
        'event_id' => $booking['event_id'],
        'event_name' => $booking['event_name'],
        'participation_fee' => $booking['participation_fee'],
        'event_date' => $booking['event_date'],
        'version' => $booking['version'] ?? ''
    ]);
}

echo "Data saved to the database.";
?>
