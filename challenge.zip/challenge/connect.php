<?php
// Connect to the database
$host = 'localhost';
$databaseName = 'codechallenge';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:host=$host;dbname=$databaseName", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}