<?php
 include 'connect.php';
// Handle filter values
$employeeName = $_GET['employee_name'] ?? '';
$eventName = $_GET['event_name'] ?? '';
$date = $_GET['date'] ?? '';

// Prepare the SQL statement with filters
$sql = "SELECT * FROM bookings WHERE employee_name LIKE :employee_name AND event_name LIKE :event_name AND event_date LIKE :event_date";
$stmt = $db->prepare($sql);
$stmt->bindValue(':employee_name', '%' . $employeeName . '%');
$stmt->bindValue(':event_name', '%' . $eventName . '%');
$stmt->bindValue(':event_date', '%' . $date . '%');
$stmt->execute();

// Fetch filtered bookings
$filteredBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate the total price of filtered entries
$totalPrice = array_sum(array_column($filteredBookings, 'participation_fee'));

// Output the filtered results in a table
?>

<!DOCTYPE html>
<html>
<head>
    <title>Event Bookings</title>
    <style>
        table {
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }
    </style>
</head>
<body>
    <h1>Event Bookings</h1>
    <form method="GET" action="">
        <label for="employee_name">Employee Name:</label>
        <input type="text" id="employee_name" name="employee_name" value="<?php echo htmlspecialchars($employeeName); ?>">

        <label for="event_name">Event Name:</label>
        <input type="text" id="event_name" name="event_name" value="<?php echo htmlspecialchars($eventName); ?>">

        <label for="date">Date:</label>
        <input type="text" id="date" name="date" value="<?php echo htmlspecialchars($date); ?>">

        <input type="submit" value="Filter">
    </form>

    <h2>Filtered Results:</h2>

    <table>
        <thead>
            <tr>
                <th>Participation ID</th>
                <th>Employee Name</th>
                <th>Employee Mail</th>
                <th>Event ID</th>
                <th>Event Name</th>
                <th>Participation Fee</th>
                <th>Event Date</th>
                <th>Version</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($filteredBookings as $booking): ?>
                <tr>
                    <td><?php echo htmlspecialchars($booking['participation_id']); ?></td>
                    <td><?php echo htmlspecialchars($booking['employee_name']); ?></td>
                    <td><?php echo htmlspecialchars($booking['employee_mail']); ?></td>
                    <td><?php echo htmlspecialchars($booking['event_id']); ?></td>
                    <td><?php echo htmlspecialchars($booking['event_name']); ?></td>
                    <td><?php echo htmlspecialchars($booking['participation_fee']); ?></td>
                    <td><?php echo htmlspecialchars($booking['event_date']); ?></td>
                    <td><?php echo htmlspecialchars($booking['version']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="5" style="text-align: right;"><strong>Total Price:</strong></td>
                <td><?php echo number_format($totalPrice, 2); ?></td>
                <td colspan="2"></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
